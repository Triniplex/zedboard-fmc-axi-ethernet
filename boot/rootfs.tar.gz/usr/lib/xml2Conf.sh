#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/usr/lib"
XML2_LIBS="-lxml2 -L/root/zynq_linux_axiethernet_driver/buildroot/output/host/usr/arm-buildroot-linux-gnueabi/sysroot/usr/lib -lz   -lm "
XML2_INCLUDEDIR="-I/usr/include/libxml2"
MODULE_VERSION="xml2-2.9.2"

